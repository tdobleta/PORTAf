import { useState, useEffect, useRef } from 'react'

const App = () => {
  const [activeSection, setActiveSection] = useState('hero')
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 })
  const [cursorHover, setCursorHover] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(null)

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['hero', 'sobre-mi', 'servicios', 'porque', 'proceso', 'testimonios', 'faq', 'contacto']
      for (const section of sections) {
        const el = document.getElementById(section)
        if (el) {
          const rect = el.getBoundingClientRect()
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section)
            break
          }
        }
      }
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY })
    }
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <>
      {/* Custom Cursor */}
      <div
        className={`cursor ${cursorHover ? 'hover' : ''}`}
        style={{ left: cursorPos.x, top: cursorPos.y }}
      />
      <div className="cursor-dot" style={{ left: cursorPos.x, top: cursorPos.y }} />

      {/* Noise Overlay */}
      <div className="noise" />

      {/* Gradient Background */}
      <div className="gradient-bg" />

      {/* Navigation */}
      <nav>
        <div className="container">
          <a href="#" className="logo" onMouseEnter={() => setCursorHover(true)} onMouseLeave={() => setCursorHover(false)}>
            Martin<span>.</span>
          </a>
          <ul className="nav-links">
            {['sobre-mi', 'servicios', 'proceso', 'testimonios', 'contacto'].map(item => (
              <li key={item}>
                <a
                  href={`#${item}`}
                  className={activeSection === item ? 'active' : ''}
                  onClick={() => scrollToSection(item)}
                  onMouseEnter={() => setCursorHover(true)}
                  onMouseLeave={() => setCursorHover(false)}
                >
                  {item.replace('-', ' ')}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero" id="hero">
        <div className="hero-content">
          <div className="hero-badge">
            <span className="dot"></span>
            Disponible para nuevos proyectos
          </div>
          <h1>
            Diseño Web<br />
            <span className="gradient-text">que Convierte</span>
          </h1>
          <p className="hero-description">
            Landing pages de alta conversión para startups, fundadores SaaS y negocios online que buscan escalar sin contratar equipo.
          </p>
          <div className="hero-cta">
            <a
              href="#contacto"
              className="btn btn-primary"
              onMouseEnter={() => setCursorHover(true)}
              onMouseLeave={() => setCursorHover(false)}
              onClick={() => scrollToSection('contacto')}
            >
              Hablemos de tu proyecto
            </a>
            <a
              href="#servicios"
              className="btn btn-secondary"
              onMouseEnter={() => setCursorHover(true)}
              onMouseLeave={() => setCursorHover(false)}
              onClick={() => scrollToSection('servicios')}
            >
              Ver servicios
            </a>
          </div>
        </div>
        <div className="scroll-indicator">
          <span>Scroll</span>
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 5v14M19 12l-7 7-7-7"/>
          </svg>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre-mi" className="about">
        <div className="container">
          <div className="about-grid">
            <div className="about-image fade-up">
              <div className="image-wrapper">
                MR
              </div>
            </div>
            <div className="about-content fade-up">
              <h3>Hola, soy Martin</h3>
              <p>
                Diseñador web especializado en crear sitios modernos y landing pages de alta conversión. Mi enfoque combina una UI limpia con una experiencia de usuario fluida, optimizada para maximizar conversiones.
              </p>
              <p>
                Trabajo principalmente con startups, fundadores SaaS e infroductores que buscan escalar sus negocios sin necesidad de contratar un equipo completo de desarrollo.
              </p>
              <div className="stats">
                <div className="stat">
                  <div className="stat-number">50+</div>
                  <div className="stat-label">Proyectos</div>
                </div>
                <div className="stat">
                  <div className="stat-number">98%</div>
                  <div className="stat-label">Clientes satisfechos</div>
                </div>
                <div className="stat">
                  <div className="stat-number">3x</div>
                  <div className="stat-label">Conversiones promedio</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios">
        <div className="container">
          <div className="section-header fade-up">
            <h2>Servicios</h2>
            <p>Soluciones de diseño adaptadas a las necesidades de tu negocio</p>
          </div>
          <div className="services-grid">
            {[
              { icon: 'monitor', title: 'Landing Pages', desc: 'Páginas de alta conversión diseñadas estratégicamente para captar leads y maximizar ventas.' },
              { icon: 'layers', title: 'Sitios Web', desc: 'Sitios web modernos y responsivos que reflejan la identidad de tu marca.' },
              { icon: 'edit', title: 'Rediseño UX/UI', desc: 'Actualiza tu sitio existente con un diseño moderno y optimizado.' },
              { icon: 'dollar', title: 'E-commerce', desc: 'Tiendas online optimizadas para ventas con diseños que guían al usuario.' },
              { icon: 'box', title: 'SaaS', desc: 'Interfaces para productos SaaS con dashboards intuitivos.' }
            ].map((service, i) => (
              <div key={i} className="service-card fade-up">
                <div className="service-icon">
                  <ServiceIcon type={service.icon} />
                </div>
                <h3>{service.title}</h3>
                <p>{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Section */}
      <section id="porque" className="why">
        <div className="container">
          <div className="section-header fade-up">
            <h2>¿Por qué trabajar conmigo?</h2>
            <p>Experiencia diseñada para resultados</p>
          </div>
          <div className="why-grid">
            {[
              { icon: 'clock', title: 'Entrega Rápida', desc: 'Tu proyecto listo en tiempo récord sin sacrificar calidad.' },
              { icon: 'check', title: '100% Premium', desc: 'Diseño de alta gama que compite con agencias que cobran $10,000+.' },
              { icon: 'dollar', title: 'Inversión Inteligente', desc: 'Precios justos para emprendedores. Máximo ROI en cada proyecto.' },
              { icon: 'message', title: 'Comunicación Directa', desc: 'Trabajo cerca de ti. Sin intermediarios, sin fricciones.' }
            ].map((item, i) => (
              <div key={i} className="why-item fade-up">
                <div className="why-icon">
                  <WhyIcon type={item.icon} />
                </div>
                <div>
                  <h4>{item.title}</h4>
                  <p>{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section id="proceso">
        <div className="container">
          <div className="section-header fade-up">
            <h2>Proceso de Trabajo</h2>
            <p>4 pasos hacia tu sitio web ideal</p>
          </div>
          <div className="process-timeline">
            {[
              { step: '1', title: 'Discovery', desc: 'Analizo tu negocio, objetivos y competencia.' },
              { step: '2', title: 'Diseño', desc: 'Creo wireframes y mockups de alta fidelidad.' },
              { step: '3', title: 'Desarrollo', desc: 'Implemento el diseño con código limpio.' },
              { step: '4', title: 'Lanzamiento', desc: 'Publicamos tu sitio con soporte incluido.' }
            ].map((item, i) => (
              <div key={i} className="process-step fade-up">
                <div className="step-number">{item.step}</div>
                <div className="step-content">
                  <h4>{item.title}</h4>
                  <p>{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonios">
        <div className="container">
          <div className="section-header fade-up">
            <h2>Lo que dicen mis clientes</h2>
            <p>Resultados reales de proyectos exitosos</p>
          </div>
          <div className="testimonials-grid">
            {[
              { text: '"Ryan transformó completamente nuestro sitio web. Se ve premium y convierte mucho mejor."', author: 'Ryan', role: 'Fundador SaaS' },
              { text: '"Rápido, profesional y con un diseño súper limpio. Entendió exactamente lo que necesitaba."', author: 'Maria', role: 'Dueña de agencia' }
            ].map((t, i) => (
              <div key={i} className="testimonial-card fade-up">
                <p className="testimonial-text">{t.text}</p>
                <div className="testimonial-author">
                  <div className="author-avatar">{t.author.substring(0, 2)}</div>
                  <div className="author-info">
                    <h5>{t.author}</h5>
                    <span>{t.role}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq">
        <div className="container">
          <div className="section-header fade-up">
            <h2>Preguntas Frecuentes</h2>
            <p>Todo lo que necesitas saber</p>
          </div>
          <div className="faq-list">
            {[
              { q: '¿Cuánto tiempo tarda el proyecto?', a: 'El tiempo varía según la complejidad. Una landing page puede estar lista en 5-7 días. Proyectos más complejos pueden tomar 2-3 semanas.' },
              { q: '¿Qué incluye el precio?', a: 'Diseño premium, desarrollo, optimización SEO básica, compatibilidad mobile, formulario de contacto y 2 rondas de revisiones.' },
              { q: '¿Trabajas con clientes de cualquier lugar?', a: 'Sí, trabajo 100% online con clientes de cualquier parte del mundo. Utilizo herramientas como Figma y Notion.' },
              { q: '¿Qué pasa si no me gusta el diseño?', a: 'Incluye 2 rondas de revisiones. Antes de comenzar el desarrollo, iteramos en el diseño hasta que estés 100% satisfecho.' }
            ].map((item, i) => (
              <div key={i} className={`faq-item ${openFaq === i ? 'active' : ''}`}>
                <button className="faq-question" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                  {item.q}
                  <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="6 9 12 15 18 9"/>
                  </svg>
                </button>
                <div className="faq-answer">
                  <div className="faq-answer-content">{item.a}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contacto" className="cta">
        <div className="container">
          <h2>¿Listo para transformar tu presencia online?</h2>
          <p>Hablemos de tu proyecto y descubre cómo puedo ayudarte a aumentar tus conversiones</p>
          <a href="mailto:martinrubio.trabajo@gmail.com" className="btn">Contactar ahora</a>
        </div>
      </section>

      {/* Footer */}
      <footer>
        <div className="container">
          <p>© 2024 Martin Rubio. Todos los derechos reservados. | <a href="mailto:martinrubio.trabajo@gmail.com">martinrubio.trabajo@gmail.com</a></p>
        </div>
      </footer>
    </>
  )
}

const ServiceIcon = ({ type }: { type: string }) => {
  const icons: Record<string, JSX.Element> = {
    monitor: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>,
    layers: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>,
    edit: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>,
    dollar: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>,
    box: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
  }
  return icons[type] || icons.monitor
}

const WhyIcon = ({ type }: { type: string }) => {
  const icons: Record<string, JSX.Element> = {
    clock: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
    check: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>,
    dollar: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>,
    message: <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
  }
  return icons[type] || icons.clock
}

export default App
